
package corsa;


public class Corsa {

    public static void main(String[] args) {
        Pista p = new Pista();
        p.setVisible(true);
        p.setLocationRelativeTo(null);
    }
    
}
